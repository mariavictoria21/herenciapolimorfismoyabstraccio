import java.util.List;

public class GestorDeInventario {
    private List<Proveedor> proveedores;
    private List<Categoría> categorías;

    public GestorDeInventario(List<Proveedor> proveedores, List<Categoría> categorías) {
        this.proveedores = proveedores;
        this.categorías = categorías;
    }

    public double calcularPrecioTotalInventario(CalculadorDePrecio calculadorDePrecio) {
        double total = 0;
        for (Proveedor proveedor : proveedores) {
            total += calculadorDePrecio.calcularPrecioTotal(proveedor.getProductos());
        }
        return total;
    }
}
