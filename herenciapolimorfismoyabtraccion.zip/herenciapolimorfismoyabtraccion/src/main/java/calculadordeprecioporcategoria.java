public class CalculadorDePrecioPorCategoría implements CalculadorDePrecio {
    private Categoría categoría;

    public CalculadorDePrecioPorCategoría(Categoría categoría) {
        this.categoría = categoría;
    }

    @Override
    public double calcularPrecioTotal(List<Producto> productos) {
        double total = 0;
        for (Producto producto : categoría.getProductos()) {
            total += producto.getPrecio() * producto.getCantidad();
        }
        return total;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Maria Victoria
 */
public class calculadordeprecioporcategoria {
    
}
