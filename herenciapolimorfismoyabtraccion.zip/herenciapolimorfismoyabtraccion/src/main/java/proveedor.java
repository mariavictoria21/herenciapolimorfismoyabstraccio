private String nombre;
	private Double precio;
	private Integer cantidad;
	//aca debemos agregar un proveedor
	
	//constructor
	public Producto() {
		
	}
	
	public Producto(String nombre, Double precio, Integer cantidad) {
		this.nombre = nombre;
		this.precio = precio;
		this.cantidad = cantidad;
	}
	
	public abstract Object getDetalles();
package com.jp.abstrac.impl;

import com.jp.abstrac.Producto;

public class ProductoElectronico extends Producto {
	private String garantia;
	private String fechaCaducidad;
	
	public Object getDetalles() {
		return "Aca debe ir la logica";
	}
}
package com.jp.models;

import java.util.List;

import com.jp.abstrac.Producto;

public class Categoria {

	private String nombre;
	private List<Producto> productos;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public List<Producto> getProductos() {
		return productos;
	}
	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}
	
	
	
}